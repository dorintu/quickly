<template>
    <div>
        <h1 class="title">Aboutfghfhdfgdfgd us</h1>
        <p>
            aldfjaljksdhf kjahsdfkj aklsdhfjkfj ahsfk jasdjfas
        </p>
        <p>
            aldfjaljksdhf kjahsdfkj aklsdhfjkfj ahsfk jasdjfas
        </p>
        <p>
            aldfjaljksdhf kjahsdfkj aklsdhfjkfj ahsfk jasdjfas
        </p>
    </div>
</template>


<style scoped>
    .title {
        color:green;
    }
</style>
